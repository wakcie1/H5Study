/**
 * Created by sc09395 on 2017/7/6 0006.
 */
(() => {
    window._tc_bridge_bar.set_navbar({
        param: {
            center: [{
                tagname: "tag_click_center", value: "苏州"
            }],
            right: [{
                tagname: "tag_click_collect", value: "我的收藏"
            }]
        },
        callback: function (data) {
            console.log(data)
        }
    })

    var slid = $(".slider").slider({
        loop: true
    });

})()